//
//  static.swift
//  extensionUse
//
//  Created by Mac on 26/03/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import Foundation
import UIKit
extension UIButton
{
    func setCornerRadius() {
        self.layer.cornerRadius = 10
        self.layer.borderWidth = 0.0
        self.clipsToBounds = true
    }
    
}
